module Users

go 1.22.3

require github.com/mattn/go-sqlite3 v1.14.42
